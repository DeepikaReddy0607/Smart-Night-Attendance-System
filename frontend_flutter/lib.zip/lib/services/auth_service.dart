import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  // 🔴 MUST be your LAPTOP IP + PORT
  static const String baseUrl = "http://10.28.237.157:8000/api/auth";

  // LOGIN
  static Future<Map<String, dynamic>> login({
    required String rollNo,
    required String password,
  }) async {
    final response = await http
        .post(
          Uri.parse("$baseUrl/login/"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "roll_no": rollNo,
            "password": password,
          }),
        )
        .timeout(const Duration(seconds: 10));

    return {
      "status": response.statusCode,
      "body": jsonDecode(response.body),
    };
  }

  // SEND OTP
  static Future<Map<String, dynamic>> sendOtp({
    required String rollNo,
    required String password,
  }) async {
    final response = await http
        .post(
          Uri.parse("$baseUrl/register/send-otp/"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "roll_no": rollNo,
            "password": password,
          }),
        )
        .timeout(const Duration(seconds: 10));
      if (!response.headers['content-type']!.contains('application/json')) {
        return {
          "status": response.statusCode,
          "body": {
            "error": "Server returned non-JSON response",
            "raw": response.body.substring(0, 100),
          }
        };
    }
    return {
      "status": response.statusCode,
      "body": jsonDecode(response.body),
    };
  }

  // VERIFY OTP
  static Future<Map<String, dynamic>> verifyOtp({
    required String rollNo,
    required String otp,
  }) async {
    final response = await http
        .post(
          Uri.parse("$baseUrl/register/verify-otp/"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "roll_no": rollNo,
            "otp": otp,
          }),
        )
        .timeout(const Duration(seconds: 10));

    return {
      "status": response.statusCode,
      "body": jsonDecode(response.body),
    };
  }
}
