import 'dart:convert';
import 'package:http/http.dart' as http;

import 'token_service.dart';

class BiometricService {
  static const String baseUrl =
      "http://10.28.237.157:8000/api/biometrics";

  /// Called ONLY after successful OS-level biometric authentication
  static Future<Map<String, dynamic>> confirmDeviceAuth({
  required String biometricType,
}) async {
  final token = await TokenService.getAccessToken();

  final response = await http.post(
    Uri.parse("$baseUrl/register/"),
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer $token",
    },
    body: jsonEncode({
      "biometric_type": biometricType, // FACE or FINGERPRINT
      "biometric_template": "LOCAL_AUTH_SUCCESS",
    }),
  );

  print("BIOMETRIC RESPONSE STATUS: ${response.statusCode}");
  print("BIOMETRIC RESPONSE BODY: ${response.body}");

  try {
    return {
      "status": response.statusCode,
      "body": jsonDecode(response.body),
    };
  } catch (_) {
    return {
      "status": response.statusCode,
      "body": {"error": "Invalid server response"},
    };
  }
}
}