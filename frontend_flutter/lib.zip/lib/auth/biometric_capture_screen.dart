import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:path_provider/path_provider.dart';

import '../services/biometric_service.dart';
import 'login_screen.dart';

class BiometricCaptureScreen extends StatefulWidget {
  final String rollNo;

  const BiometricCaptureScreen({
    super.key,
    required this.rollNo,
  });

  @override
  State<BiometricCaptureScreen> createState() =>
      _BiometricCaptureScreenState();
}

class _BiometricCaptureScreenState extends State<BiometricCaptureScreen> {
  CameraController? _cameraController;
  late FaceDetector _faceDetector;

  bool _isDetecting = false;
  bool _faceDetected = false;
  bool _isProcessing = false;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableLandmarks: true,
        enableContours: false,
      ),
    );
  }

  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
      (cam) => cam.lensDirection == CameraLensDirection.front,
    );

    _cameraController = CameraController(
      frontCamera,
      ResolutionPreset.medium,
      enableAudio: false,
    );

    await _cameraController!.initialize();
    _startFaceDetection();
    setState(() {});
  }

  void _startFaceDetection() {
    _cameraController!.startImageStream((CameraImage image) async {
      if (_isDetecting) return;
      _isDetecting = true;

      final inputImage = _convertToInputImage(image);
      final faces = await _faceDetector.processImage(inputImage);

      if (mounted) {
        setState(() {
          _faceDetected = faces.length == 1;
        });
      }

      _isDetecting = false;
    });
  }

  InputImage _convertToInputImage(CameraImage image) {
    final bytes = image.planes.fold<List<int>>(
      [],
      (prev, plane) => prev..addAll(plane.bytes),
    );

    final metadata = InputImageMetadata(
      size: Size(image.width.toDouble(), image.height.toDouble()),
      rotation: InputImageRotation.rotation0deg,
      format: InputImageFormat.nv21,
      bytesPerRow: image.planes.first.bytesPerRow,
    );

    return InputImage.fromBytes(bytes: bytes, metadata: metadata);
  }

  Future<void> _captureAndSubmit() async {
    if (!_faceDetected) return;

    setState(() => _isProcessing = true);

    try {
      await _cameraController!.stopImageStream();
      final image = await _cameraController!.takePicture();

      final bytes = await image.readAsBytes();
      final base64Image = base64Encode(bytes);

      final result = await BiometricService.registerBiometric(
        rollNo: widget.rollNo,
        biometricType: "FACE",
        biometricTemplate: base64Image,
      );

      if (result["status"] == 201) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (_) => false,
        );
      } else {
        _showError("Biometric registration failed");
      }
    } catch (e) {
      _showError("Camera error occurred");
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _faceDetector.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_cameraController == null ||
        !_cameraController!.value.isInitialized) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Biometric Capture"),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          Expanded(
            child: CameraPreview(_cameraController!),
          ),

          Container(
            padding: const EdgeInsets.all(16),
            width: double.infinity,
            color: _faceDetected ? Colors.green : Colors.red,
            child: Text(
              _faceDetected
                  ? "Face detected. You may capture."
                  : "No face detected. Align your face.",
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white),
            ),
          ),

          const SizedBox(height: 12),

          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed:
                  (_faceDetected && !_isProcessing) ? _captureAndSubmit : null,
              child: _isProcessing
                  ? const CircularProgressIndicator()
                  : const Text("CAPTURE & REGISTER"),
            ),
          ),

          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
