import 'package:flutter/material.dart';
import 'dart:async';
import '../services/student_service.dart';
import 'biometric_register_screen.dart'; 
import '../services/token_service.dart';
class HostelDetailsScreen extends StatefulWidget {

  const HostelDetailsScreen({
    super.key,
    });

  @override
  State<HostelDetailsScreen> createState() => _HostelDetailsScreenState();
}

class _HostelDetailsScreenState extends State<HostelDetailsScreen> {
  String? selectedHostel;
  String? selectedBlock;
  final TextEditingController roomController = TextEditingController();
  bool isLoading = false;

  final Map<String, List<String>> hostelBlockMap = {
    "Aryabhatta Hostel": ["Block A", "Block B"],
    "Vivekananda Hostel": ["Block C", "Block D"],
  };

  List<String> get hostels => hostelBlockMap.keys.toList();
  List<String> get blocks =>
      selectedHostel != null ? hostelBlockMap[selectedHostel]! : [];

  Future<void> _submitHostelDetails() async {
    if (selectedHostel == null ||
        selectedBlock == null ||
        roomController.text.trim().isEmpty) {
      _showError("All fields are required");
      return;
    }

    setState(() => isLoading = true);

    try {
      final token = await TokenService.getAccessToken();
      print("TOKEN BEFORE HOSTEL = $token");

      final result = await StudentService.assignHostel(
        hostel: selectedHostel!,
        block: selectedBlock!,
        roomNumber: roomController.text.trim(),
      ).timeout(const Duration(seconds: 10));

      if(!mounted) return;

      if (result["status"] == 200 || result["status"] == 201) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const BiometricRegisterScreen(),
          ),
        );
      } else {
        _showError("Hostel assignment failed");
      }
    } on TimeoutException{
      _showError("Server not reachable");
    }
      catch (e) {
      _showError("Hostel allocation error: $e");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    roomController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Hostel Allocation"),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Hostel Details",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            const SizedBox(height: 24),

            DropdownButtonFormField<String>(
              value: selectedHostel,
              items: hostels
                  .map((h) => DropdownMenuItem(value: h, child: Text(h)))
                  .toList(),
              onChanged: (v) {
                setState(() {
                  selectedHostel = v;
                  selectedBlock = null;
                });
              },
              decoration: const InputDecoration(
                labelText: "Hostel",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            DropdownButtonFormField<String>(
              value: selectedBlock,
              items: blocks
                  .map((b) => DropdownMenuItem(value: b, child: Text(b)))
                  .toList(),
              onChanged:
                  selectedHostel == null ? null : (v) => setState(() => selectedBlock = v),
              decoration: const InputDecoration(
                labelText: "Block",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            TextField(
              controller: roomController,
              decoration: const InputDecoration(
                labelText: "Room Number",
                border: OutlineInputBorder(),
              ),
            ),

            const Spacer(),

            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: isLoading ? null : _submitHostelDetails,
                child: isLoading
                    ? const CircularProgressIndicator()
                    : const Text("CONFIRM HOSTEL DETAILS"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
