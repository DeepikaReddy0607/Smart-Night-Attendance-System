import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

import '../services/biometric_service.dart';
import '../student/student_dashboard.dart';

class BiometricRegisterScreen extends StatefulWidget {
  const BiometricRegisterScreen({super.key});

  @override
  State<BiometricRegisterScreen> createState() =>
      _BiometricRegisterScreenState();
}

class _BiometricRegisterScreenState extends State<BiometricRegisterScreen> {
  final LocalAuthentication _auth = LocalAuthentication();
  bool isLoading = false;

  Future<void> _startBiometric() async {
    try {
      // 1️⃣ Check device support
      final bool isSupported = await _auth.isDeviceSupported();
      final List<BiometricType> biometrics =
          await _auth.getAvailableBiometrics();

      if (!isSupported || biometrics.isEmpty) {
        _showError("No biometrics enrolled on this device");
        return;
      }

      setState(() => isLoading = true);

      // 2️⃣ Trigger system biometric authentication
      final bool authenticated = await _auth.authenticate(
        localizedReason: "Verify biometrics to continue",
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );

      if (!authenticated) {
        setState(() => isLoading = false);
        _showError("Biometric verification failed");
        return;
      }

            // Detect biometric type
      String biometricType = "FINGERPRINT";

      if (biometrics.contains(BiometricType.face)) {
        biometricType = "FACE";
      }

      // 3️⃣ Notify backend
      final result = await BiometricService.confirmDeviceAuth(
        biometricType: biometricType,
      );

      setState(() => isLoading = false);

      if (result["status"] == 200 || result["status"] == 201) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const StudentDashboard()),
          (_) => false,
        );
      } else {
        _showError(
          result["body"]?["error"] ?? "Biometric confirmation failed",
        );
      }
    } on PlatformException catch (e) {
      setState(() => isLoading = false);
      _showError(e.message ?? "Biometric system error");
    } catch (e) {
      setState(() => isLoading = false);
      _showError("Biometric error: $e");
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Biometric Verification"),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.fingerprint, size: 80),
            const SizedBox(height: 24),
            const Text(
              "Verify Biometrics",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            const Text(
              "Use your device biometric to continue",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: isLoading ? null : _startBiometric,
                child: isLoading
                    ? const CircularProgressIndicator()
                    : const Text("VERIFY"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
